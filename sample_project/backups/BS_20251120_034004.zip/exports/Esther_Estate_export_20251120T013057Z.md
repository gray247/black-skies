# The Summons

## Basement Pulse
Mara Ibarra enters Basement Pulse to map the estate's sealed corridors. The atmosphere leans toward respite as footsteps echo from nowhere.

The beat shifts when an old ally speaks through the static, keeping the scene in escalation mode and aiming for roughly 890 words.

## Locked Parlor
Ezra Cole enters Locked Parlor to keep the generator coil alive. The atmosphere leans toward revelation as old floorboards complain at every move.

The beat shifts when the diary on the desk updates itself, keeping the scene in payoff mode and aiming for roughly 930 words.
