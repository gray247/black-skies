# Continuity Review (Sample)

_No cross-scene warnings yet. Use this file to track continuity notes during testing._
